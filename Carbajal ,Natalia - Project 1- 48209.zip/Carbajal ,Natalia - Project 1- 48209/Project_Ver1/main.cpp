/* 
 * File:   main.cpp
 * Author: Natalia Carbajal
 * Purpose: Project 1 - Connect 4 - Version 1
 */

//Starting maping out the header files for the project for the game, board, and players 
//Build does not yet run

#include "Game.h"
#include "Board.h"

//Starts the game
int main() {
  Game game;
  game.start();
}