/* 
 * File:   main.cpp
 * Author: Natalia Carbajal
 * Purpose: Project 1 - Connect 4 - Version 3
 * Succesfully finished corresponding cpp files
 */

#include "Game.h"
#include "Board.h"
//Starts the game
int main() {
  Game game;
  game.start();
}

